(function ($) {
    $.fn.serializeFormJSON = function () {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };
})(jQuery);

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#product_image').attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
}

function getBase64Image(img) {
    var canvas = document.createElement("canvas");
    canvas.width = img.width;
    canvas.height = img.height;
    var ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);
    var dataURL = canvas.toDataURL("image/png");
    return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
}

function download(content, fileName, contentType) {
    var a = document.createElement("a");
    var file = new Blob([content], {type: contentType});
    a.href = URL.createObjectURL(file);
    a.download = fileName;
    a.click();
}

$(document).ready(function(){
    $(document).on('change', '.btn-file :file', function() {
		var input = $(this),
			label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
		input.trigger('fileselect', [label]);
	});

	$('.form-checkbox-control.1 .checkbox input')
	    .on('change', function() {
            $('.form-checkbox-control.1 .checkbox input')
                .not(this).prop('checked', false);
    });

    $('.form-checkbox-control.2 .checkbox input')
	    .on('change', function() {
            $('.form-checkbox-control.2 .checkbox input')
                .not(this).prop('checked', false);
    });

    $('.form-checkbox-control.3 .checkbox input')
	    .on('change', function() {
            $('.form-checkbox-control.3 .checkbox input')
                .not(this).prop('checked', false);
    });

    $('.form-checkbox-control.5 .checkbox input')
	    .on('change', function() {
            $('.form-checkbox-control.5 .checkbox input')
                .not(this).prop('checked', false);
    });

    $('.btn-file :file').on('fileselect', function(event, label) {
        var input = $(this).parents('.input-group').find(':text'),
            log = label;

        if( input.length ) {
            input.val(log);
        } else {
            if( log ) alert(log);
        }
    });
        
    $("#img_inp").change(function(){
        readURL(this);
    });

    $("#navbar_menu li a").click(function() {
        $("#navbar_menu li").removeClass('selected');
        $(this).parent().addClass('selected');

        var id = $(this).attr('id');
        switch (id){
            case 'farma':
                $("#farmacêutico :input").prop("disabled", false);
                $("#cons_health :input").prop("disabled", true);
                $("#farmacêutico").show();
                $("#cons_health").hide();
                break;
            case 'ch':
                $("#farmacêutico :input").prop("disabled", true);
                $("#cons_health :input").prop("disabled", false);
                $("#cons_health").show();
                $("#farmacêutico").hide();
                break;
            default:
                $("#farmacêutico :input").prop("disabled", false);
                $("#cons_health :input").prop("disabled", false);
                $("#cons_health").show();
                $("#farmacêutico").show();
        }
    });

    $('form').submit(function (e) {
        e.preventDefault();
        var data = $(this).serializeFormJSON();
        var image_element = document.getElementById('product_image');
        var image_data = getBase64Image(image_element);
        var product_image = {"Product Image": image_data};
        
        $.extend(true, data, product_image);
        download(JSON.stringify(data), 'output.json', 'application/json');
    });
});