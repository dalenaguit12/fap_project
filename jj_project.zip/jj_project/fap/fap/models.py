from django.conf import settings
from django.db import models
import uuid
from django.utils import  timezone
from multiselectfield import MultiSelectField
from django.forms import ChoiceField
from django import forms

class User(models.Model):
    #Model for fap users
    user_account_type = (
        ('admin', 'Admin'),
        ('client', 'Client'),
    )

    user_id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        help_text='Unique ID for this particular user.'
    )
    user_fname = models.CharField(max_length=300)
    user_mname = models.CharField(max_length=300)
    user_lname = models.CharField(max_length=300)
    user_email = models.EmailField(max_length=300)
    user_companyname = models.CharField(max_length=300)
    user_account_type = models.CharField(
        max_length=10,
        choices=user_account_type,
        blank=True,
        default='client',
        help_text='User type',
    )
    user_name = models.CharField(max_length=20)
    user_password = models.CharField(max_length=20)

    # Metadata
    class Meta:
        ordering = ['user_lname', 'user_fname']

    # Methods
    def get_absolute_url(self):
        """Returns the url to access a particular user instance."""
        return reverse('user-detail', args=[str(self.user_id)])

    def __str__(self):
        """String for representing the Model object."""
        return f'{self.user_fname}, {self.user_lname}'

CANAL_A_SER_DISTRIBUIDO = (
        ('far', 'Farmácia'),
        ('hos', 'Hospitalar'),
    )

class Farmacêutico(models.Model):
    f_codigo_ean = models.BigIntegerField(verbose_name='Código EAN')
    f_nome_de_produto = models.CharField(
        max_length=100, verbose_name='Nome do Produto')
    f_marca_familia = models.CharField(
        max_length=100, verbose_name='Marca/Família')
    f_apresentacao_completa = models.CharField(
        max_length=100, verbose_name='Apresentação completa')
    f_fabricante = models.CharField(max_length=100, verbose_name='Fabricante')
    f_quem_comercializara = models.CharField(
        max_length=100, verbose_name='Quem Comercializará')
    f_principio_ativo = models.CharField(
        max_length=100, verbose_name='Princípio Ativo')
    f_preco_lista = models.DecimalField(
        max_digits=19,
        decimal_places=2,
        verbose_name='Preço Lista ( ICMS = 18% ou 12% )'
    )
    f_unidade_de_venda = models.CharField(
        max_length=100, verbose_name='Unidade de Venda')
    f_data_de_lancamento = models.DateField(
        auto_now=False,
        verbose_name='Data de Lançamento'
    )
    f_ct_sugerida = models.CharField(
        max_length=100, verbose_name='CT Sugerida (PMB)')
    f_kit = models.CharField(
        max_length=100, verbose_name='Kit (S/N)', blank=True)
    f_detalhamento_kit = models.CharField(
        max_length=100, verbose_name='Detalhamento Kit*', blank=True)

    novo_nova = models.CharField(
        max_length=100,
        null=True
    )
    etico_popular = models.CharField(
        max_length=20,
        null=True
    )
    referencia_marca_similar_generico = models.CharField(
        max_length=10,
        null=True
    )
    canal_a_ser_distribuido = MultiSelectField(
        choices=CANAL_A_SER_DISTRIBUIDO,
        max_choices=2,
        max_length=30,
        verbose_name='Canal a ser distribuido'
    )
    # patentado = models.BooleanField(verbose_name='Patenteado')
    pertence_a_lista = models.CharField(
        max_length=10,
        verbose_name='Pertence a lista:'
    )
    data_de_vencimento_da_patente = models.DateField(
        null=True,
        blank=True,
        auto_now=False,
        verbose_name='Data de vencimento da patente'
    )
    registro_anvisa = models.BigIntegerField(null=True, verbose_name='Registro ANVISA')
    # product_image = models.ImageField(verbose_name='Product Image', blank=True)

class TableEntry(models.Model):
    codigo_de_barras = models.TextField(verbose_name='Código de Barras',blank=True)
    dosagem_forma = models.TextField(verbose_name='Dosagem/Forma da apresentação',blank=True)
    descricao = models.TextField(verbose_name='Descrição Completa',blank=True)
    unidade = models.TextField(verbose_name='Unidade de Venda',blank=True)
    ct_nec = models.TextField(verbose_name='CT/NEC',blank=True)
    ps_1 = models.TextField(verbose_name='Preço Sugerido',blank=True)
    ps_2 = models.TextField(verbose_name='Preço Sugerido',blank=True)
    pl_1 = models.TextField(verbose_name='Preço Lista',blank=True)
    pl_2 = models.TextField(verbose_name='Preço Lista',blank=True)
