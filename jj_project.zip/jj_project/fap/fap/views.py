from django.contrib import auth
from django.contrib import auth
from django.contrib.auth import authenticate, logout
from django.shortcuts import redirect
from django.shortcuts import render
from django.template import RequestContext
from django.db import connection
from django.http import QueryDict, HttpResponseRedirect
from django.views.generic import ListView, TemplateView

from .forms import FarmacêuticoForm
from .models import Farmacêutico


def login(request):
    context = {}
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)
        if user:
            auth.login(request, user)
            return redirect('formpage')
        else:
            context["error"] = "The email or password you've entered doesn't match any account."

    return render(request, 'login.html', context)

def user_logout(request):
    logout(request)
    return redirect('loginpage')

def signup(request):
    return render(request, 'signup.html')

def form(request):

    context=RequestContext(request)

    if not request.user.is_authenticated:
        return redirect('loginpage')
    return render(request, 'form.html')

def create_farmaceutico(request):
    context = {}
    if request.method == "POST":
        form = FarmacêuticoForm(request.POST, request.FILES)
        #print(form)
        #print('form')
        if form.is_valid():
            #print('xxxxxxx')
            data = form.cleaned_data
            # json_raw = data.readlines()
            # for (k, v) in data.items():
            #
            #     print("Key: " + k)
            #     print("Value: " + str(v))
            # for e in data.objects.all():
            #
            #     print(e.f_codigo_ean)
            # form = data['pertence_a_lista'].split(",")
            form.save()
            return render(request, 'testedit.html', {'data': data})  # display data in html


       # else:
           # print('yyyyyyy') #test only
    else:
        form = FarmacêuticoForm()
    context['form'] = form
    # pass
    return render(request, 'form.html', context)

def rows_count(request):
        # count = Farmacêutico.objects.all().count()
        count = Farmacêutico.objects.all()
        # data = FarmacêuticoForm.objects.all()

        context = {'count': count}

        return render(request, 'rowcount.html', context)

def transaction(request):
    return render(request, 'transaction.html')






