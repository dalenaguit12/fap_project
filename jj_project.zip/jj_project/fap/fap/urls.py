from django.contrib import admin
from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
                  path('', views.login, name='loginpage'),  # main page
                  path('signup', views.signup),
                  path('form', views.form, name='formpage'),
                  path('admin/', admin.site.urls),
                  path('user_logout', views.user_logout),
                  path('post/<int:pk>/', views.form, name='post_detail'),
                  path('farmaceutico', views.create_farmaceutico,
                       name='farmaceutico'),
                  path('rowscount', views.rows_count),
                  path('transact', views.transaction)
              ] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
