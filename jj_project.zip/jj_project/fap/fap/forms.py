from django import forms
from crispy_forms.helper import FormHelper
from .models import Farmacêutico
from django.forms import ChoiceField, RadioSelect, ModelForm, TextInput

NOVO_NOVA = (
    ('nov_pro', 'Novo Produto'),
    ('nov_apr', 'Novo Apresentação'),
)

ETICO_POPULAR = (
    ('eti_com_tar', 'Ético - com tarja'),
    ('pop_sem_tar', 'Popular - sem tarja'),
)

REFERENCIA_MARCA_SIMILAR_GENERICO = (
    ('ref', 'Referência'),
    ('mar', 'Marca'),
    ('sim', 'Similar'),
    ('gen', 'Genérico'),
)

PERTENCE_A_LISTA = (
    ('pos', 'Positiva'),
    ('neg', 'Negativa'),
    ('neu', 'Neutra'),
)
CANAL_A_SER_DISTRIBUIDO = (
        ('far', 'Farmácia'),
        ('hos', 'Hospitalar'),
    )

class FarmacêuticoForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super(FarmacêuticoForm, self).__init__(*args, **kwargs)
        self.fields['canal_a_ser_distribuido'].error_messages = {
         'required': 'Canal a ser distribuido is required'}
        self.fields['f_data_de_lancamento'].error_messages = {
         'invalid': 'Data de Lançamento invalid format. Use MM/DD/YY'}

    novo_nova = ChoiceField(
        choices=NOVO_NOVA,
        widget=RadioSelect(),
        label=''
    )
    etico_popular = ChoiceField(
        choices=ETICO_POPULAR,
        widget=RadioSelect(),
        label=''
    )
    referencia_marca_similar_generico = ChoiceField(
        choices=REFERENCIA_MARCA_SIMILAR_GENERICO,
        widget=RadioSelect(),
        label=''
    )
    pertence_a_lista = ChoiceField(
        choices=PERTENCE_A_LISTA,
        widget=RadioSelect()
    )


    class Meta:
        model = Farmacêutico
        fields = '__all__'